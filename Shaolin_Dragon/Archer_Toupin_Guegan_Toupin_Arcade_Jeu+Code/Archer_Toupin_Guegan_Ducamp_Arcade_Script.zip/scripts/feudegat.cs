﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class feudegat : MonoBehaviour
{

    //Instancier le projectile
    public float projectileSpeed;
   
    private Rigidbody2D rigidbody;
   

    // Start is called before the first frame update
    void Start()
    {
      
        rigidbody = GetComponent<Rigidbody2D>();

    }

    //Détection de la collision entre la boule de feu et le mur + Add score

    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.CompareTag("Mur"))
        {
            GameObject.FindGameObjectWithTag("GM").GetComponent<Gamemanager>().AddScore(); 
           
            Destroy(gameObject);
        }


     //Détection de la collision entre la boule de feu et le moine

        if (collision.gameObject.CompareTag("Ennemy"))
        {
            
            {
                SoundManagerScript.PlaySound("moinecri");
                GameObject.FindGameObjectWithTag("GM").GetComponent<Gamemanager>().ResetScore();
                Destroy(gameObject);

            }
            
        }

    }
}
