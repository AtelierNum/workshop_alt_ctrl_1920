﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;
using UnityEngine.UI;


public class Gamemanager : MonoBehaviour
{
 public GameObject gameOver , restartbutton;
    public GameObject gameOver2 , restartbutton2;
    public int Score = 0;
    public int NmbOfProcEscape = 1;
    public TextMeshProUGUI ScoreDisplay;
    public TextMeshProUGUI yourScore;
    public TextMeshProUGUI highScore;


    private void Start() // initialisation de la partie 
    {
        highScore.text = PlayerPrefs.GetInt("HighScore").ToString(); // mise en place de l'affichage de High Score

        // masquer l'hud de game over
        yourScore.gameObject.SetActive(false);
        highScore.gameObject.SetActive(false);
        gameOver2.SetActive(false); 
        restartbutton2.SetActive(false);
        gameOver.SetActive(false);
        restartbutton.SetActive(false);
        

    }

    public void AddScore() // incrémentation du score par multiplication
    {
        Score += 100*NmbOfProcEscape;
        NmbOfProcEscape++;
    }

    public void ResetScore() // reset du multiplicateur apres s'etre pris une boule de feu
    {
        NmbOfProcEscape = 1;
    }
    private void Update() // affichage du score actuel
    {
        ScoreDisplay.text = "score : " + Score +  " X " + NmbOfProcEscape +" !";
        //yourScore.text = "Your Score : " + Score;
    }
    public void Restart() // initialisation de la procédure de restart 
    {
        yourScore.text = "Your Score : " + Score;    // affichage du score actuel apres avoir perdu
        if (Score >= PlayerPrefs.GetInt("HighScore")) // affichage du high score de la session actuelle apres avoir perdu
        PlayerPrefs.SetInt("HighScore" , Score);

        // affichage de l'hud game over
        yourScore.gameObject.SetActive(true);
        highScore.gameObject.SetActive(true);
        gameOver.SetActive(true);
        restartbutton.SetActive(true);
        gameOver2.SetActive(true);
        restartbutton2.SetActive(true);

    }
}
