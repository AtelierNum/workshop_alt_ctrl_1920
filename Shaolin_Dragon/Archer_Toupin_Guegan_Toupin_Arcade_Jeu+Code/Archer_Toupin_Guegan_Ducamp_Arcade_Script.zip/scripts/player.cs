﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class player : MonoBehaviour
{
    // définition des vies du moine
    private Rigidbody2D rigidbody;
    public float life = 2;
    // Start is called before the first frame update
    void Start()
    {
        rigidbody = GetComponent<Rigidbody2D>();
    }

    // Dégats des collisions moine/projectile
    
        private void OnCollisionEnter2D(Collision2D collision)
        {



        if (collision.gameObject.CompareTag("Ball") && life >0)
        {
            life -= 1;
            Debug.Log("life="+life);
        }
         if(collision.gameObject.CompareTag("Ball") && life <= 0)
        {
            Destroy(gameObject);
            GameObject.FindGameObjectWithTag("GM").GetComponent<Gamemanager>().Restart();
            SoundManagerScript.PlaySound("gong");
            
        }
        }

    }


