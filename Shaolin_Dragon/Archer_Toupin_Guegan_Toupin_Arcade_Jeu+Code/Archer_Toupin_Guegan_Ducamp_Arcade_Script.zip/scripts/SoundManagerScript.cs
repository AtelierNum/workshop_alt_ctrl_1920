﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SoundManagerScript : MonoBehaviour
{
    //Déclarer les variables du son
    public static AudioClip fireSound, dragonSound, moinehurtSound, gameoverSound;
    static AudioSource audioSrc;

    
    void Start()
    {
        fireSound = Resources.Load<AudioClip>("flamme1");
        dragonSound = Resources.Load<AudioClip>("dragonok");
        moinehurtSound = Resources.Load<AudioClip>("moinecri");
        gameoverSound = Resources.Load<AudioClip>("gong");

        audioSrc = GetComponent<AudioSource>();
    }

    // Associer les sons et régler leur volume
    public static void PlaySound(string clip)
    {

        switch (clip)
        {
            case "flamme1":
                audioSrc.volume = 1;
                audioSrc.PlayOneShot(fireSound);
                break;
            case "dragonok":
                audioSrc.volume = 0.5f;
                audioSrc.PlayOneShot(dragonSound);
                break;
            case "moinecri":
                audioSrc.volume = 1;
                audioSrc.PlayOneShot(moinehurtSound);
                break;
            case "gong":
                audioSrc.PlayOneShot(gameoverSound);
                break;
        }

    }
}
