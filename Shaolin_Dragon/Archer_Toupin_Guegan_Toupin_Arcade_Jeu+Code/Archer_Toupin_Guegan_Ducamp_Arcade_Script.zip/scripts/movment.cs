﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class movment : MonoBehaviour
{
    // Instancier les movements de chaque perso
    public Transform t;
    public Transform e;
    //public ArduinoData datas;

    private float  positionSphereX ;
    private float rotationSphereX ;
    public float flex;
    public bool connected = false;
    public float pot;
    public bool buttonState = false;


    // Invoked when a line of data is received from the serial device.
    void OnMessageArrived(string msg)
        // recéption des données des sensors d'arduino sur Unity, on vérifie que les données arrivent
        // on associe des actions faites en fonction de ces valeurs
    {
        connected = true;
        // Debug.Log(msg);
        ArduinoData datas = JsonUtility.FromJson<ArduinoData>(msg);
        flex = datas.flex;
        pot = datas.pot;
        buttonState = datas.buttonState;


        //  t.localScale = new Vector3(datas.pot / 10.0f, datas.pot / 10.0f, datas.pot / 10.0f);

       // e.localPosition = new Vector3(datas.flex / 5f, 0, 0);
        positionSphereX = Mathf.Lerp(positionSphereX, datas.accelY*185.0f , 0.16f) ;
        if(t!=null)
            t.localPosition = new Vector3(positionSphereX, t.localPosition.y, t.localPosition.z);
        float angleDragon = ExtensionMethods.Remap(datas.pot, 0, 1023, -80, 80);
       // e.localRotation = Quaternion.Euler(0, 0, angleDragon) ;

        if (buttonState == true)
        {
            SceneManager.LoadScene(1);
        }

    }

    // Invoked when a connect/disconnect event occurs. The parameter 'success'
    // will be 'true' upon connection, and 'false' upon disconnection or
    // failure to connect.
    void OnConnectionEvent(bool success) 
    {
       Debug.Log("connected : " + success);
        
    }
}


public static class ExtensionMethods
{

    public static float Remap(this float value, float from1, float to1, float from2, float to2)
    {
        return (value - from1) / (to1 - from1) * (to2 - from2) + from2;
    }

}

public class ArduinoData // stockage des valeurs des récepteurs de la carte Arduino 
{
    public int flex;
    public int pot;
    public float accelY;
    public bool buttonState;
   
   
}

