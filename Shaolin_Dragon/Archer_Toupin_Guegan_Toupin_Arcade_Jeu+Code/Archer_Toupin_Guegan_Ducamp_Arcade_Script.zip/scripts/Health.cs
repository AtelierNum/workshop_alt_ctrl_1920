﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Health : MonoBehaviour
{
    // Déclarer les life et leurs sprites
    public int health;
    public int numOfHearts;

    public Image[] hearts;
    public Sprite fullHeart;
    public Sprite emptyHeart;

    // Déclarer le nombre de vie
    private Rigidbody2D rigidbody;
    public float life = 2;

    // Start is called before the first frame update
    void Start()
    {
        rigidbody = GetComponent<Rigidbody2D>();
    }

    // Update is called once per frame

    // Conséquence des collisions projectile/moines
    private void OnCollisionEnter2D(Collision2D collision)
    {


        // 1 vie enlevée lorsqu'il y a collision
        if (collision.gameObject.CompareTag("Ball") && life > 0)
        {
            life -= 1;
            health -= 1;
            Debug.Log("life=" + life);
            
        }
        // Ce qui se passe lorsqu'il n'y a plus de vie (game over + jouer le son)
        if (collision.gameObject.CompareTag("Ball") && life <= 0)
        {
            health = 0;
            Destroy(gameObject);
            GameObject.FindGameObjectWithTag("GM").GetComponent<Gamemanager>().Restart();
            
        }
    }





    // Gestion des sprites lorsque des vies sont enlevées (-1 = sprite vide...)
    void Update()
    {
        if (health > numOfHearts)
        {
            health = numOfHearts;
        }

        for (int i = 0; i < hearts.Length; i++)
        {

            if (i < health)
            {
                hearts[i].sprite = fullHeart;
            }
            else
            {
                hearts[i].sprite = emptyHeart;

            }

            if (i < numOfHearts)
            {
                hearts[i].enabled = true;
            }
            else
            {
                hearts[i].enabled = false;
            }


        }
    }

}