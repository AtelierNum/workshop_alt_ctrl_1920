﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Restart : MonoBehaviour
{
    // Reload la scène lorsqu'on appuie sur restart
      public void restartScene()
    {
        Application.LoadLevel (Application.loadedLevel);
    }

}
