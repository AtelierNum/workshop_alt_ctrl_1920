﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class instancefeu : MonoBehaviour
{
    public Transform firePosition;
    public GameObject projectile;
    private float flex;
    public GameObject mov;
    public bool shoot = false;
    public float temps = 0;
    public float power = 50;
    public bool ready = false;
    public float offset;
    

    private void Update()

        // Mettre en place le systeme de shoot pour le dragon d'après le tensor flex
    {
        
        if (temps <= 0)
        {
            shoot = true;
        }
        else
        {
            temps -= Time.deltaTime; 
        }

        if (mov.GetComponent<movment>().flex < 450) // armer le shoot apres une certaine valeur de flexion
        {
            ready = true;
        }
        if (ready == true && mov.GetComponent<movment>().flex >500 && mov.GetComponent<movment>().connected == true && shoot == true) // tirer apres un relachement sur la valeur initiale de flexion
        {
            
            Debug.Log("shoot");
            GameObject newBullet =Instantiate(projectile, firePosition.position, transform.rotation);
            newBullet.GetComponent<Rigidbody2D>().AddForce(-transform.up * power, ForceMode2D.Impulse);
            
            shoot = false;
            temps = 2;
            ready = false;

            SoundManagerScript.PlaySound("dragonok");
            SoundManagerScript.PlaySound("flamme1");


        }

       
        


    }

}
